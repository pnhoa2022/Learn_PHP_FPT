# CKFinder 3 Package for Laravel {#laravel_package}

CKFinder 3 can also be installed as a Laravel package.

The Laravel Package source code along with documentation and usage examples is available in a dedicated
GitHub repository: https://github.com/ckfinder/ckfinder-laravel-package.

Please use the [GitHub Issues page](https://github.com/ckfinder/ckfinder-laravel-package/issues) to report issues and submit feature requests for the CKFinder 3 Package for Laravel.