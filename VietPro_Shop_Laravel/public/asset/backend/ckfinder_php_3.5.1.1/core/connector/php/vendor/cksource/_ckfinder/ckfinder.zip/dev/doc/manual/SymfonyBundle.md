# CKFinder 3 Bundle for Symfony {#symfony_bundle}

CKFinder 3 can also be installed as a Symfony bundle.

The Symfony 3 Bundle source code along with documentation and usage examples is available in a dedicated
GitHub repository: https://github.com/ckfinder/ckfinder-symfony3-bundle.

For Symfony 2, please have a look at: https://github.com/ckfinder/ckfinder-symfony2-bundle.

Please use the [GitHub Issues page](https://github.com/ckfinder/ckfinder-symfony2-bundle/issues) to report issues and submit feature requests for the CKFinder 3 Bundle for Symfony 2.